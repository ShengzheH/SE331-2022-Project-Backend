package se331.rest.security.entity;

public enum AuthorityName {
    ROLE_USER, ROLE_ADMIN
}